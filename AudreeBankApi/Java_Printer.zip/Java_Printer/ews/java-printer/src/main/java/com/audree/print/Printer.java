package com.audree.print;

import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintException;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.DocAttributeSet;
import javax.print.attribute.HashAttributeSet;
import javax.print.attribute.HashDocAttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.JobName;
import javax.print.attribute.standard.MediaSizeName;
import javax.print.attribute.standard.PrinterName;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.printing.PDFPageable;
import org.apache.pdfbox.printing.PDFPrintable;

public class Printer {

	private static void print(PDDocument document) throws IOException, PrinterException {
		PrinterJob job = PrinterJob.getPrinterJob();
		job.setPageable(new PDFPageable(document));
		job.print();
	}

	public static void printFileName(String FileName, String printerName) throws Exception {

		File pdfFile = new File(FileName);
		PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
		pras.add(new JobName(FileName.substring(FileName.lastIndexOf("\\") + 1, FileName.length()), null));
		pras.add(MediaSizeName.ISO_A4);
		DocFlavor flavor = DocFlavor.INPUT_STREAM.PDF;

		HashAttributeSet has = new HashAttributeSet();
		has.add(new PrinterName(printerName, null));
		PrintService[] printService = PrintServiceLookup.lookupPrintServices(flavor, has);

		if (printService.length > 0) {
			DocPrintJob pj = printService[1].createPrintJob();
			try {
				FileInputStream fis = new FileInputStream(pdfFile);
				DocAttributeSet das = new HashDocAttributeSet();
				Doc doc = new SimpleDoc(fis, flavor, das);
				pj.print(doc, pras);
			} catch (FileNotFoundException fe) {
				throw fe;
			} catch (PrintException e) {
				throw e;
			}
		} else {
			System.out.println("No printers found");
		}
	}
}
