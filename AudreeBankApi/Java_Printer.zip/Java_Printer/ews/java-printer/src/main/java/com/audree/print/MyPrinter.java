package com.audree.print;

public class MyPrinter {

	public static void main(String[] args) {
		try {
			String fileName = "D:\\Projects\\Audree\\Java_Printer\\ews\\java-printer\\src\\f1.pdf";
			String printerName = "printer1";
			Printer.printFileName(fileName, printerName);
			System.out.println("Print Success");
		} catch (Exception ex) {
			System.out.println(ex.toString());
		}
	}
}